"""دیتابیس SQLite محلی برنامه + ذخیره امن کلید API.

روی ویندوز، کلید API با Windows DPAPI (CryptProtectData/CryptUnprotectData)
رمزنگاری و در پوشه AppData کاربر ذخیره می‌شود؛ این رمزنگاری فقط برای همان
کاربر ویندوزی روی همان سیستم قابل بازگشایی است (دقیقاً همان روشی که در
اپ نمونه قبلی هم استفاده شده بود). روی سیستم‌عامل‌های دیگر (فقط برای توسعه/تست)
یک Fallback ساده و *غیر امن* استفاده می‌شود که باید در README مستند شود.
"""
from __future__ import annotations

import base64
import json
import os
import shutil
import sqlite3
import sys
from pathlib import Path

APP_NAME = "CRMQualityReviewer"


def app_data_dir() -> Path:
    """Return portable per-install data directory.

    Frozen EXE builds store settings beside the EXE in ``user_data``. During
    source development the same rule uses the repository root, which keeps
    development and portable execution behavior consistent. ``MYBARID_DATA_DIR``
    can override this location for server or shared deployments.
    """
    override = os.environ.get("MYBARID_DATA_DIR")
    if override:
        d = Path(override).expanduser().resolve()
    elif getattr(sys, "frozen", False):
        d = Path(sys.executable).resolve().parent / "user_data"
    else:
        project_root = Path(__file__).resolve().parents[1]
        d = project_root / "user_data"
    d.mkdir(parents=True, exist_ok=True)
    _migrate_legacy_data(d)
    return d


def _migrate_legacy_data(target: Path) -> None:
    """Copy legacy AppData files once; never delete or overwrite portable data."""
    if sys.platform != "win32":
        return
    legacy = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / APP_NAME
    if not legacy.exists() or legacy.resolve() == target.resolve():
        return
    for name in ("app.db", "api-key.bin", "criteria_config.json", "analysis_snapshot.pkl", "analysis_snapshot.previous.pkl"):
        source = legacy / name
        destination = target / name
        if source.exists() and not destination.exists():
            try:
                shutil.copy2(source, destination)
            except OSError:
                pass


DB_PATH = app_data_dir() / "app.db"
SECRET_PATH = app_data_dir() / "api-key.bin"


def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    conn = get_connection()
    try:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            );
            CREATE TABLE IF NOT EXISTS ai_cache (
                signature TEXT PRIMARY KEY,
                payload TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            """
        )
        conn.commit()
    finally:
        conn.close()


def get_setting(key: str, default=None):
    conn = get_connection()
    try:
        row = conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
        if row is None:
            return default
        try:
            return json.loads(row["value"])
        except (json.JSONDecodeError, TypeError):
            return row["value"]
    finally:
        conn.close()


def set_setting(key: str, value) -> None:
    conn = get_connection()
    try:
        conn.execute(
            "INSERT INTO settings(key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, json.dumps(value, ensure_ascii=False)),
        )
        conn.commit()
    finally:
        conn.close()


def get_ai_cache(signature: str) -> dict | None:
    conn = get_connection()
    try:
        row = conn.execute("SELECT payload FROM ai_cache WHERE signature = ?", (signature,)).fetchone()
        return json.loads(row["payload"]) if row else None
    finally:
        conn.close()


def set_ai_cache(signature: str, payload: dict) -> None:
    import datetime

    conn = get_connection()
    try:
        conn.execute(
            "INSERT INTO ai_cache(signature, payload, created_at) VALUES (?, ?, ?) "
            "ON CONFLICT(signature) DO UPDATE SET payload=excluded.payload, created_at=excluded.created_at",
            (signature, json.dumps(payload, ensure_ascii=False), datetime.datetime.now().isoformat()),
        )
        conn.commit()
    finally:
        conn.close()


def clear_ai_cache() -> None:
    conn = get_connection()
    try:
        conn.execute("DELETE FROM ai_cache")
        conn.commit()
    finally:
        conn.close()


# ------------------------------------------------------------ Secret key --

def _win_protect(value: str) -> bytes:
    from ctypes import POINTER, Structure, byref, c_byte, c_void_p, cast, string_at, windll
    from ctypes.wintypes import DWORD

    class DataBlob(Structure):
        _fields_ = [("cbData", DWORD), ("pbData", POINTER(c_byte))]

    raw = value.encode("utf-8")
    source_buffer = (c_byte * len(raw)).from_buffer_copy(raw)
    source, target = DataBlob(len(raw), source_buffer), DataBlob()
    if not windll.crypt32.CryptProtectData(byref(source), None, None, None, None, 0, byref(target)):
        raise OSError("Windows DPAPI نتوانست کلید را رمزنگاری کند.")
    try:
        return string_at(target.pbData, target.cbData)
    finally:
        windll.kernel32.LocalFree(cast(target.pbData, c_void_p))


def _win_unprotect(value: bytes) -> str:
    from ctypes import POINTER, Structure, byref, c_byte, c_void_p, cast, string_at, windll
    from ctypes.wintypes import DWORD

    class DataBlob(Structure):
        _fields_ = [("cbData", DWORD), ("pbData", POINTER(c_byte))]

    source_buffer = (c_byte * len(value)).from_buffer_copy(value)
    source, target = DataBlob(len(value), source_buffer), DataBlob()
    if not windll.crypt32.CryptUnprotectData(byref(source), None, None, None, None, 0, byref(target)):
        raise OSError("کلید ذخیره‌شده برای این کاربر ویندوز قابل خواندن نیست.")
    try:
        return string_at(target.pbData, target.cbData).decode("utf-8")
    finally:
        windll.kernel32.LocalFree(cast(target.pbData, c_void_p))


def save_api_key(value: str) -> None:
    if sys.platform == "win32":
        SECRET_PATH.write_bytes(_win_protect(value))
    else:
        # Fallback غیرامن، فقط برای توسعه روی غیر ویندوز. در README تصریح می‌شود.
        SECRET_PATH.write_bytes(base64.b64encode(value.encode("utf-8")))


def load_api_key() -> str:
    if not SECRET_PATH.exists():
        return ""
    try:
        if sys.platform == "win32":
            return _win_unprotect(SECRET_PATH.read_bytes())
        return base64.b64decode(SECRET_PATH.read_bytes()).decode("utf-8")
    except OSError:
        return ""


def delete_api_key() -> None:
    if SECRET_PATH.exists():
        SECRET_PATH.unlink()


def mask_key(key: str) -> str:
    if not key:
        return ""
    if len(key) <= 8:
        return "•" * len(key)
    return key[:4] + "•" * (len(key) - 8) + key[-4:]
