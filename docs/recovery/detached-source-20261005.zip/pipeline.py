from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Callable

from ai.analyzer import analyze_cases
from ai.providers import AISettings
from analysis.data_quality import compute_data_health
from analysis.experts import aggregate_experts, primary_expert
from analysis.scoring import CaseScoreBreakdown, score_case
from analysis.suspicious import find_suspicious_cases
from config.criteria_config import CriteriaConfig
from data.cleaner import CaseBundle, build_cases, build_task_pseudo_cases
from data.records import NoteRecord, TaskRecord


@dataclass
class Dataset:
    notes: list[NoteRecord]
    tasks: list[TaskRecord]
    cases: dict[str, CaseBundle]
    unmatched_tasks: list[TaskRecord]
    notes_summary: dict
    tasks_summary: dict


def dataset_from_records(notes: list[NoteRecord], tasks: list[TaskRecord]) -> Dataset:
    """ساخت Dataset از رکوردهای نرمال‌شده منبع داده CRM.

    این تابع عمداً هیچ وابستگی به فایل یا فرمت Excel ندارد. اتصال CRM یا
    لایه ذخیره‌سازی داخلی باید رکوردهای نرمال‌شده را به این نقطه تحویل دهد.
    """
    cases, unmatched = build_cases(notes, tasks)
    return Dataset(
        notes=notes, tasks=tasks, cases=cases, unmatched_tasks=unmatched,
        notes_summary={}, tasks_summary={},
    )


def filter_period(
    dataset: Dataset, start: datetime, end: datetime, expert_filter: set[str] | None = None,
) -> tuple[dict[str, CaseBundle], list]:
    notes_in = [n for n in dataset.notes if n.note_date and start <= n.note_date <= end]
    tasks_in = [t for t in dataset.tasks if t.created_on and start <= t.created_on <= end]
    cases, unmatched = build_cases(notes_in, tasks_in)
    # تکمیل فیلدهای توصیفی (عنوان/مشتری/...) از دیتاست کامل، در صورت خالی بودن در بازه فیلترشده
    for key, bundle in cases.items():
        full = dataset.cases.get(key)
        if not full:
            continue
        bundle.case_title = bundle.case_title or full.case_title
        bundle.customer = bundle.customer or full.customer
        bundle.owner = bundle.owner or full.owner
        bundle.service = bundle.service or full.service
        bundle.scenario = bundle.scenario or full.scenario
        bundle.case_description = bundle.case_description or full.case_description
    if expert_filter:
        cases = {k: v for k, v in cases.items() if primary_expert(v) in expert_filter}
    return cases, unmatched


def filter_period_task_mode(
    dataset: Dataset, start: datetime, end: datetime, expert_filter: set[str] | None = None,
) -> dict[str, CaseBundle]:
    """معادل filter_period ولی برای کارشناسان پشتیبانی فنی: واحد بررسی Task
    است، نه Case. هر Task مستقیماً به کارشناس ثبت‌کننده‌اش (Created By)
    نسبت داده می‌شود."""
    tasks_in = [t for t in dataset.tasks if t.created_on and start <= t.created_on <= end]
    if expert_filter:
        tasks_in = [t for t in tasks_in if (t.created_by or "") in expert_filter]
    return build_task_pseudo_cases(tasks_in)


def score_all(cases: dict[str, CaseBundle], config: CriteriaConfig,
              ai_results: dict[str, dict] | None = None, unit: str = "case") -> dict[str, CaseScoreBreakdown]:
    ai_results = ai_results or {}
    return {key: score_case(case, config, ai_results.get(key), unit=unit) for key, case in cases.items()}


@dataclass
class PeriodResult:
    cases: dict[str, CaseBundle]
    scores: dict[str, CaseScoreBreakdown]
    ai_errors: dict[str, str]


def run_period(
    dataset: Dataset, config: CriteriaConfig, start: datetime, end: datetime,
    ai_settings: AISettings, progress_cb: Callable[[int, int, str], None] | None = None,
    expert_filter: set[str] | None = None, unit: str = "case",
) -> PeriodResult:
    if unit == "task":
        cases = filter_period_task_mode(dataset, start, end, expert_filter)
    else:
        cases, _ = filter_period(dataset, start, end, expert_filter)
    # در حالت Task، AI فعلاً اجرا نمی‌شود (معیارهای Task مستقل همگی Rule-Based تعریف شده‌اند)
    ai_results, ai_errors = ({}, {}) if unit == "task" else analyze_cases(cases, config, ai_settings, progress_cb)
    scores = score_all(cases, config, ai_results, unit=unit)
    return PeriodResult(cases=cases, scores=scores, ai_errors=ai_errors)


def run_analysis(
    dataset: Dataset, config: CriteriaConfig,
    period: tuple[datetime, datetime],
    ai_settings: AISettings, progress_cb: Callable[[str, int, int], None] | None = None,
    expert_filter: set[str] | None = None, unit: str = "case",
) -> dict:
    def _progress(i, n, key):
            if progress_cb:
                progress_cb("تحلیل موارد", i, n)

    current = run_period(dataset, config, period[0], period[1], ai_settings, _progress, expert_filter, unit)
    experts = aggregate_experts(current.cases, current.scores)
    ranking = [
        {
            "expert": expert,
            "score": stats.avg_final,
            "cases": stats.case_count,
            "status": "در حال ارزیابی" if stats.avg_final is None else "امتیاز ثبت شد",
        }
        for expert, stats in experts.items()
    ]
    ranking.sort(key=lambda row: (row["score"] is None, -(row["score"] or 0)))

    health_checks, health_index = compute_data_health(
        dataset.notes, dataset.tasks, dataset.cases, dataset.unmatched_tasks
    )

    if unit == "task":
        all_tasks = dataset.tasks
        if expert_filter:
            all_tasks = [t for t in all_tasks if (t.created_by or "") in expert_filter]
        suspicious_pool = build_task_pseudo_cases(all_tasks)
    else:
        suspicious_pool = dataset.cases
        if expert_filter:
            suspicious_pool = {k: v for k, v in dataset.cases.items() if primary_expert(v) in expert_filter}
    suspicious = find_suspicious_cases(suspicious_pool)

    return {
        "analysis": current,
        "experts": experts,
        "ranking": ranking,
        "data_health_checks": health_checks,
        "data_health_index": health_index,
        "suspicious": suspicious,
        "unit": unit,
    }
